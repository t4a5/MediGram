// MediGram UAE - Interactive Script
// Designed by Yara Azmi - 2025

document.addEventListener('DOMContentLoaded', () => {
  // Smooth scrolling for in-page navigation links (if any)
  document.querySelectorAll('.nav a').forEach(link => {
    if (link.hash) {
      link.addEventListener('click', function (e) {
        if (this.hash !== '') {
          e.preventDefault();
          const target = document.querySelector(this.hash);
          if (target) {
            window.scrollTo({
              top: target.offsetTop - 80,
              behavior: 'smooth'
            });
          }
        }
      });
    }
  });

  // Button hover animation
  const buttons = document.querySelectorAll('button, .home-buttons a');
  buttons.forEach(btn => {
    btn.addEventListener('mouseover', () => {
      btn.style.transform = 'scale(1.05)';
      btn.style.transition = 'transform 0.2s ease';
    });
    btn.addEventListener('mouseout', () => {
      btn.style.transform = 'scale(1)';
    });
  });

  // Fade-in effect when scrolling
  const elements = document.querySelectorAll('section, .login-box, .signup-box, form');
  const fadeIn = () => {
    elements.forEach(el => {
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight - 100) {
        el.style.opacity = 1;
        el.style.transform = 'translateY(0)';
      }
    });
  };

  window.addEventListener('scroll', fadeIn);
  window.addEventListener('load', () => {
    elements.forEach(el => {
      el.style.opacity = 0;
      el.style.transform = 'translateY(40px)';
      el.style.transition = 'all 1s ease';
    });
    fadeIn();
  });

  // Form submission handling:
  // Only intercept forms marked as demo (data-demo="true") or forms with no action attribute.
  document.querySelectorAll('form').forEach(form => {
    const action = form.getAttribute('action');
    const demo = form.dataset.demo === 'true';
    if (!action || demo) {
      form.addEventListener('submit', e => {
        e.preventDefault();
        alert('Your form has been submitted successfully! شكراً لتواصلك معنا 💙');
        form.reset();
      });
    }
  });
});